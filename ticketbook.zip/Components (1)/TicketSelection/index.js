import {useState} from 'react'
import './index.css'

const TicketSelection = ({onBook}) => {
  const [ticketCount, setTicketCount] = useState(1)

  const handleIncrement = () => {
    setTicketCount(prevCount => prevCount + 1)
  }

  const handleDecrement = () => {
    setTicketCount(prevCount => (prevCount > 1 ? prevCount - 1 : 1))
  }

  const handleBookTickets = () => {
    onBook(ticketCount)
  }

  return (
    <div className="card-container">
      <div className="card">
        <h2 className="card-heading">Select Number of Tickets</h2>
        <div className="inc">
          <button className="dec-btn" type="button" onClick={handleDecrement}>
            -
          </button>
          <span className="num">{ticketCount}</span>
          <button className="inc-btn" type="button" onClick={handleIncrement}>
            +
          </button>
        </div>
        <div className="book-button">
          <button
            className="book-btn"
            type="button"
            onClick={handleBookTickets}
          >
            Book Tickets
          </button>
        </div>
      </div>
    </div>
  )
}

export default TicketSelection
