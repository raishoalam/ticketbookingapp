import './index.css'

const Payment = ({totalTickets, totalPrice}) => (
  <div className="payment-section">
    <div className="payment-container">
      <h2 className="payment-heading">Payment Details</h2>
      <p className="pra">Total Tickets: {totalTickets}</p>
      <hr />
      <p className="pra1">Total Price: ${totalPrice}</p>
      <hr />
      <div className="payment-btn">
        <button
          className="payment-button"
          type="button"
          onClick={() => alert('Payment Successfully')}
        >
          Proceed to Payment
        </button>
      </div>
    </div>
  </div>
)

export default Payment
