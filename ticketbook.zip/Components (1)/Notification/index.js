import './index.css'

const Notification = ({message}) => (
  <div>
    <p className="notification">{message}</p>
  </div>
)

export default Notification
