import {Link} from 'react-router-dom'

const Home = () => (
  <div>
    <h1>Welcome to Ticket Booking App</h1>
    <Link to="/ticket-selection">Book Tickets</Link>
  </div>
)

export default Home
